package com.example.paymentservice;

public interface PaymentService {
	
	public void processPayment();

}
