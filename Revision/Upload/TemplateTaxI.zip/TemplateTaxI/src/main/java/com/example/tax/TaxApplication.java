package com.example.tax;

import java.util.Scanner;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class TaxApplication {

	public static void main(String[] args) {
		// Take ClassPathXmlApplicationContext from applicationContext.xml file
		ClassPathXmlApplicationContext context =new ClassPathXmlApplicationContext("applicationContext.xml");
		Scanner sc =new Scanner(System.in);
		while(true) {
	        System.out.println("Please select the type of tax you want to pay:");
	        System.out.println("1. Income Tax");
	        System.out.println("2. Property Tax");
	        System.out.println("3. Exit");
	        
	        int choice = sc.nextInt();
	        String taxChoice = "";
	        
	        switch(choice) {
	        case 1:
	        	//Bean Id is selected here.
	            taxChoice = "incomeTax";
//	            Tax incomeTax = (Tax) context.getBean("incomeTax");
//	            incomeTax.setTaxableAmount(1200000);
//	            incomeTax.calculateTaxAmount();
//	            System.out.println("Income Tax Amount to Pay: ₹" + incomeTax.getTaxAmount());
//	            if (!incomeTax.isTaxPayed()) {
//	                incomeTax.payTax();
//	            }
	            break;
	        case 2:
	        	//Bean Id is selected here.
	            taxChoice = "propertyTax";
//	            Tax propertyTax = (Tax) context.getBean("propertyTax");
//	            propertyTax.setTaxableAmount(800000);
//	            propertyTax.calculateTaxAmount();
//	            System.out.println("Property Tax Amount to Pay: ₹" + propertyTax.getTaxAmount());
//	            if (!propertyTax.isTaxPayed()) {
//	                propertyTax.payTax();
//	            }
	            break;
	        case 3:
	            System.out.println("Exiting...");
	            return;
	        default:
	            System.out.println("Invalid choice");
	            return;
	    }	
	        if (!taxChoice.isEmpty()) {
	            Tax tax = (Tax) context.getBean(taxChoice);
	            System.out.println(tax.getTaxType());
	        }
	        }

}

}
